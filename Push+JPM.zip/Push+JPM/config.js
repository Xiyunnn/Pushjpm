//===Script kek gini di jual parah kalian
const chalk = require("chalk")
const fs = require("fs")
//=====Ganti dengan nomer kalian===
global.ownerNumber = "6285294278841@s.whatsapp.net"
global.nomerOwner = "6285294278841"
global.nomorOwner = "6285294278841"
global.namaDeveloper = "XiyunZ-dev"
global.nameowner = "Xiyunn"
global.namaBot = "HongYi"
global.packname = ""
global.author = ""
global.thumb = fs.readFileSync("./babycat/babycat.png")

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
